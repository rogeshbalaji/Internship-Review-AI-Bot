# AI-Based Internship Review Automation System

This Python project automates internship review reminders, GitHub repository summaries, AI-generated feedback, and scheduling of the next review.

## Workflow

1. Student details and review dates are stored in `students.xlsx`.
2. On the review date, the script sends a reminder email with your submission form link.
3. After the student submits the form, copy the GitHub repository URL into that student's `GitHub Link` cell in `students.xlsx`.
4. Run the review command. The script summarizes public GitHub repository metadata, recent commits, file paths, and README content, then asks Claude to draft feedback.
5. The feedback email includes the next review date, or completion notice after the final review.

**Important limitation:** The provided script does not automatically import Google/Microsoft Form responses, and it does not download or execute student code. Form-to-Excel integration would need to be added separately. Private GitHub repositories require an appropriately authorized token and may need additional handling.

## Requirements

- Python 3.10 or newer recommended
- Anthropic API key
- SMTP email account and app password
- A submission form URL
- Internet access for the GitHub API and Anthropic API

## Installation

```bash
python -m venv .venv
```

Activate the environment:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS/Linux**
```bash
source .venv/bin/activate
```

Install packages:

```bash
pip install -r requirements.txt
```

## Configuration

Set these environment variables before running the script:

- `ANTHROPIC_API_KEY` — your Claude API key
- `SMTP_HOST` — e.g. `smtp.gmail.com`
- `SMTP_PORT` — `465` for SSL SMTP
- `SMTP_USER` — sender email address
- `SMTP_PASS` — email app password, not your normal account password
- `FORM_URL` — Google Forms or Microsoft Forms submission link
- `GITHUB_TOKEN` — optional GitHub token for API rate limits
- `CLAUDE_MODEL` — optional model override; default is `claude-sonnet-4-5`

Do not share your API keys or commit them to GitHub. Use environment variables or a local `.env` file kept out of version control.

## Commands

Create the Excel template:

```bash
python internship_review.py init
```

Send reminders to students whose review date is today:

```bash
python internship_review.py remind
```

Review submitted GitHub links, send feedback, and schedule the next review:

```bash
python internship_review.py review
```

Run reminders followed by reviews:

```bash
python internship_review.py all
```

## Excel columns

- `Name`
- `Email`
- `Review Date` — use `YYYY-MM-DD`
- `Review Time` — e.g. `10:00`
- `Review No` — starts at `1`
- `Status` — `Scheduled`, `Awaiting Submission`, or `Completed`
- `GitHub Link` — fill after the form is submitted
- `Recording Link` — optional tracking field
- `Feedback` — stores the previous review feedback

## Daily automation

Use Windows Task Scheduler or cron to run `python internship_review.py all` once per day. Test first with a test student and a safe email account.
