"""
AI-Based Internship Review Automation System

Flow:
    Excel -> reminder email (with submission link) -> AI review of the
    student's GitHub work -> feedback email + next review date -> repeat.

Commands:
    python internship_review.py init     # create students.xlsx template
    python internship_review.py remind   # email students whose review is today
    python internship_review.py review   # AI-review submissions, send feedback, schedule next
    python internship_review.py all      # remind, then review (use this for the daily job)

Setup:
    pip install -r requirements.txt
    Set environment variables:
        ANTHROPIC_API_KEY   your Claude API key
        SMTP_HOST           e.g. smtp.gmail.com
        SMTP_PORT           e.g. 465
        SMTP_USER           sender email address
        SMTP_PASS           app password (not your normal password)
        FORM_URL            link to your Google/Microsoft Form for submissions
        GITHUB_TOKEN        optional, avoids GitHub API rate limits

Important:
    The current script does not automatically read form responses. After a student
    submits the form, copy their GitHub repository link into the matching row in
    students.xlsx under "GitHub Link", then run `python internship_review.py review`.
"""
import os
import re
import smtplib
import ssl
import sys
from datetime import date, datetime, timedelta
from email.message import EmailMessage

import anthropic
import pandas as pd
import requests

# ---------------- Settings ----------------
EXCEL_FILE = "students.xlsx"
REVIEW_GAP_DAYS = 7          # days between reviews
TOTAL_REVIEWS = 4            # internship completes after this many reviews
REVIEW_TIME = "10:00"        # default time for the next review
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5")
FORM_URL = os.getenv("FORM_URL", "https://forms.gle/your-form-link")

REVIEW_CRITERIA = """
1. Progress since the last review (commit history, new features)
2. Code quality and structure (readability, organisation, naming)
3. README and documentation (setup steps, project description)
4. Completeness against a typical internship project scope
5. Best practices (tests, error handling, no secrets committed)
"""

COLUMNS = [
    "Name", "Email", "Review Date", "Review Time", "Review No", "Status",
    "GitHub Link", "Recording Link", "Feedback",
]
# Status values: Scheduled -> Awaiting Submission -> Scheduled ... -> Completed


# ---------------- Excel helpers ----------------
def load_df() -> pd.DataFrame:
    df = pd.read_excel(EXCEL_FILE, dtype=str).fillna("")
    for col in COLUMNS:
        if col not in df.columns:
            df[col] = ""
    return df


def save_df(df: pd.DataFrame) -> None:
    df.to_excel(EXCEL_FILE, index=False)


def cmd_init() -> None:
    if os.path.exists(EXCEL_FILE):
        print(f"{EXCEL_FILE} already exists - not overwriting.")
        return
    sample = {
        "Name": "Student One",
        "Email": "student@example.com",
        "Review Date": date.today().isoformat(),
        "Review Time": REVIEW_TIME,
        "Review No": "1",
        "Status": "Scheduled",
    }
    pd.DataFrame([sample], columns=COLUMNS).fillna("").to_excel(EXCEL_FILE, index=False)
    print(f"Created {EXCEL_FILE}. Dates must be in YYYY-MM-DD format.")


# ---------------- Email ----------------
def send_email(to: str, subject: str, body: str) -> None:
    required = ["SMTP_HOST", "SMTP_USER", "SMTP_PASS"]
    missing = [key for key in required if not os.getenv(key)]
    if missing:
        raise RuntimeError("Missing email configuration: " + ", ".join(missing))

    msg = EmailMessage()
    msg["From"] = os.environ["SMTP_USER"]
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    ctx = ssl.create_default_context()
    port = int(os.getenv("SMTP_PORT", "465"))
    with smtplib.SMTP_SSL(os.environ["SMTP_HOST"], port, context=ctx) as server:
        server.login(os.environ["SMTP_USER"], os.environ["SMTP_PASS"])
        server.send_message(msg)


# ---------------- Step 1: reminders ----------------
def cmd_remind() -> None:
    df = load_df()
    today = date.today().isoformat()
    for i, row in df.iterrows():
        if row["Status"] == "Scheduled" and str(row["Review Date"])[:10] == today:
            body = (
                f"Hi {row['Name']},\n\n"
                f"Your internship review #{row['Review No']} is scheduled for "
                f"{str(row['Review Date'])[:10]} at {row['Review Time']}.\n\n"
                f"Please submit the following using this link:\n{FORM_URL}\n"
                "  - Your GitHub repository link\n"
                "  - Your screen recording link showing your progress\n\n"
                "Regards,\nInternship Coordinator"
            )
            send_email(row["Email"], f"Internship Review #{row['Review No']} - Submission Link", body)
            df.at[i, "Status"] = "Awaiting Submission"
            print(f"Reminder sent to {row['Name']}")
    save_df(df)


# ---------------- Step 2: read the student's work from GitHub ----------------
def github_summary(url: str) -> str:
    m = re.search(r"github\.com/([^/\s]+)/([^/\s#?]+)", url)
    if not m:
        return f"Could not parse GitHub link: {url}"
    owner, repo = m.group(1), m.group(2).removesuffix(".git")
    headers = {"Accept": "application/vnd.github+json"}
    if os.getenv("GITHUB_TOKEN"):
        headers["Authorization"] = f"Bearer {os.environ['GITHUB_TOKEN']}"
    base = f"https://api.github.com/repos/{owner}/{repo}"

    def get(path, **kw):
        h = {**headers, **kw.pop("headers", {})}
        return requests.get(base + path, headers=h, timeout=30, **kw)

    parts = []
    r = get("")
    if r.ok:
        info = r.json()
        parts.append(f"Repo: {info['full_name']} | language: {info.get('language')} | "
                     f"last push: {info.get('pushed_at')}")
    else:
        return f"Could not access repo ({r.status_code}). It may be private or the link is wrong."

    r = get("/commits", params={"per_page": 15})
    if r.ok:
        commits = [f"- {c['commit']['author']['date'][:10]}: {c['commit']['message'].splitlines()[0]}"
                   for c in r.json()]
        parts.append("Recent commits:\n" + "\n".join(commits))

    r = get("/git/trees/HEAD", params={"recursive": "1"})
    if r.ok:
        paths = [t["path"] for t in r.json().get("tree", []) if t["type"] == "blob"][:80]
        parts.append("Files:\n" + "\n".join(paths))

    r = get("/readme", headers={"Accept": "application/vnd.github.raw+json"})
    parts.append("README (first 3000 chars):\n" + (r.text[:3000] if r.ok else "No README found."))
    return "\n\n".join(parts)


# ---------------- Step 3: AI review ----------------
def ai_review(name: str, review_no: str, repo_info: str, previous_feedback: str) -> str:
    if not os.getenv("ANTHROPIC_API_KEY"):
        raise RuntimeError("Missing ANTHROPIC_API_KEY environment variable.")

    prompt = f"""You are reviewing an intern's project for a coordinator.
Student: {name}
Review number: {review_no} of {TOTAL_REVIEWS}

Review criteria:
{REVIEW_CRITERIA}

Feedback given at the previous review (check whether it was addressed):
{previous_feedback or 'None - this is the first review.'}

Student's repository data:
{repo_info}

Write the feedback as a plain-text email body with these sections:
SUMMARY (2-3 lines), STRENGTHS, CHANGES REQUIRED (numbered, specific, actionable),
SCORE (out of 10). Be constructive and concise. Only comment on what the data shows;
if something cannot be judged from the data, say so."""
    client = anthropic.Anthropic()
    resp = client.messages.create(
        model=MODEL, max_tokens=1200,
        messages=[{"role": "user", "content": prompt}],
    )
    return resp.content[0].text


# ---------------- Steps 4-6: feedback, next review, repeat ----------------
def cmd_review() -> None:
    df = load_df()
    for i, row in df.iterrows():
        if row["Status"] != "Awaiting Submission" or not row["GitHub Link"].strip():
            continue
        print(f"Reviewing {row['Name']}...")
        repo_info = github_summary(row["GitHub Link"].strip())
        feedback = ai_review(row["Name"], row["Review No"], repo_info, row["Feedback"])
        try:
            review_no = int(row["Review No"] or 1)
        except ValueError:
            print(f"Skipping {row['Name']}: Review No must be a number.")
            continue

        if review_no >= TOTAL_REVIEWS:
            footer = "\n\nThis was your final review. Congratulations on completing the internship!"
            df.at[i, "Status"] = "Completed"
        else:
            next_date = (datetime.now() + timedelta(days=REVIEW_GAP_DAYS)).date().isoformat()
            footer = (
                f"\n\nNEXT REVIEW: #{review_no + 1} on {next_date} at {REVIEW_TIME}\n"
                f"Submission link: {FORM_URL}"
            )
            df.at[i, "Review No"] = str(review_no + 1)
            df.at[i, "Review Date"] = next_date
            df.at[i, "Review Time"] = REVIEW_TIME
            df.at[i, "Status"] = "Scheduled"

        df.at[i, "Feedback"] = feedback
        df.at[i, "GitHub Link"] = ""
        send_email(row["Email"], f"Internship Review #{review_no} - Feedback",
                   f"Hi {row['Name']},\n\n{feedback}{footer}\n\nRegards,\nInternship Coordinator")
        print(f"Feedback sent to {row['Name']}")
    save_df(df)


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "init":
        cmd_init()
    elif cmd == "remind":
        cmd_remind()
    elif cmd == "review":
        cmd_review()
    elif cmd == "all":
        cmd_remind()
        cmd_review()
    else:
        print(__doc__)
